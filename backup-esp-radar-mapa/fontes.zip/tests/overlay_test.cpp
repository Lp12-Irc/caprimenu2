// language: C++20 / file: overlay_test.cpp / runtime: MSVC + DX11 / target: Windows x64
#include "overlay.hpp"
#include "menu.hpp"
#include "brand.hpp"
#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"
#include <cstdio>
#include <stdexcept>
#include <cstring>

static void check(bool ok, const char* message) {
    if (!ok) throw std::runtime_error(message);
}
int main(int argc, char** argv) {
    bool interactive = argc > 1 && std::strcmp(argv[1], "--interactive") == 0;
    ImGui_ImplWin32_EnableDpiAwareness();
    WNDCLASSW wc{};
    wc.lpfnWndProc = DefWindowProcW; wc.hInstance = GetModuleHandleW(nullptr);
    wc.lpszClassName = L"HillBlackTestHost";
    wc.hbrBackground = CreateSolidBrush(RGB(28,33,41));
    RegisterClassW(&wc);
    HWND host = CreateWindowW(wc.lpszClassName, L"HillBlack UI test host", WS_OVERLAPPEDWINDOW,
        120, 80, 1160, 800, nullptr, nullptr, wc.hInstance, nullptr);
    ShowWindow(host, SW_SHOW); SetForegroundWindow(host);
    try {
        Overlay overlay;
        check(overlay.create("HillBlack UI test host"), "create overlay");
        ImGui::CreateContext();
        ImGui::GetIO().IniFilename = nullptr;
        ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
        check(Brand::init(overlay.device()), "embedded Capri avatar decodes");
    Menu::apply_theme();
        ImGui::GetIO().Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf", 18);
        check(ImGui_ImplWin32_Init(overlay.hwnd()), "win32 init");
        check(ImGui_ImplDX11_Init(overlay.device(), overlay.context()), "dx11 init");
        auto styles = [&] { return GetWindowLongPtrW(overlay.hwnd(), GWL_EXSTYLE); };
        check((styles() & WS_EX_TRANSPARENT) != 0, "closed menu passes input");
        overlay.set_interactive(true);
        check((styles() & (WS_EX_TRANSPARENT | WS_EX_NOACTIVATE)) == 0, "open menu captures input");
        POINT hit{20,20}; ClientToScreen(overlay.hwnd(), &hit);
        const auto hit_position = MAKELPARAM(hit.x, hit.y);
        check(SendMessageW(overlay.hwnd(), WM_NCHITTEST, 0, hit_position) == HTCLIENT, "interactive hit-test");
        SendMessageW(overlay.hwnd(), WM_CHAR, 'a', 0);
        ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
        check(ImGui::GetIO().InputQueueCharacters.Size == 1, "WndProc forwards text to ImGui");
        ImGui::EndFrame();
        check(overlay.begin_frame(), "initial frame");
        RECT client{}; GetClientRect(host, &client);
        check(overlay.width() == client.right && overlay.height() == client.bottom, "client size");
        SetWindowPos(host, nullptr, 150, 90, 1100, 760, SWP_NOZORDER | SWP_NOACTIVATE);
        check(overlay.begin_frame(), "resize frame");
        GetClientRect(host, &client);
        check(overlay.width() == client.right && overlay.height() == client.bottom, "resized client size");
        ID3D11RenderTargetView* rtv = nullptr;
        overlay.context()->OMGetRenderTargets(1, &rtv, nullptr);
        check(rtv != nullptr, "render target survives resize"); rtv->Release();
        overlay.set_interactive(false);
        check((styles() & WS_EX_TRANSPARENT) != 0, "close restores passthrough");
        check(SendMessageW(overlay.hwnd(), WM_NCHITTEST, 0, hit_position) == HTTRANSPARENT, "closed hit-test");
        overlay.set_interactive(true);
        Config cfg; cfg.menu_open = true;
        AuthInfo info; info.result = AuthResult::OK; info.hwid = "TESTE LOCAL DE INTERFACE";
        info.expires_at = "Ambiente isolado";
        Menu menu; bool running = true, last = false;
        int frames = 0;
        while (running && overlay.begin_frame()) {
            bool key = (GetAsyncKeyState(cfg.menu_key) & 0x8000) != 0;
            if (key && !last) cfg.menu_open = !cfg.menu_open;
            last = key;
            overlay.set_interactive(cfg.menu_open);
            if (!overlay.visible()) { Sleep(20); continue; }
            ImGui_ImplDX11_NewFrame(); ImGui_ImplWin32_NewFrame(); ImGui::NewFrame();
            if (cfg.menu_open) menu.render(cfg, info, running);
            overlay.set_interactive(cfg.menu_open);
            ImGui::Render(); ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData()); overlay.end_frame();
            if (!interactive && ++frames >= 4) break;
        }
        Brand::shutdown();
    ImGui_ImplDX11_Shutdown(); ImGui_ImplWin32_Shutdown(); ImGui::DestroyContext();
        overlay.destroy();
        std::puts("PASS: input styles, hit tests, ImGui text events, client alignment, DX11 resize, render.");
    } catch (const std::exception& e) {
        std::fprintf(stderr, "FAIL: %s\n", e.what()); DestroyWindow(host); return 1;
    }
    DestroyWindow(host);
    DeleteObject(wc.hbrBackground);
    return 0;
}
