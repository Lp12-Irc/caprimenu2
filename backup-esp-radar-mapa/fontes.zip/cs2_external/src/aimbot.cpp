#include "aimbot.hpp"
#include <algorithm>
#include <limits>

static constexpr float PI = 3.14159265f;
float Aimbot::normalize(float a) const { return std::isfinite(a) ? std::remainder(a, 360.f) : 0.f; }
Vec3 Aimbot::calc_angle(const Vec3& src, const Vec3& dst) const {
    const Vec3 d = dst - src;
    return {-std::atan2(d.z, std::hypot(d.x, d.y)) * 180.f / PI, std::atan2(d.y, d.x) * 180.f / PI, 0};
}
Vec3 Aimbot::get_bone_pos(const PlayerEnt& p, int bone) const {
    if (!p.bones_valid) return p.head;
    const int index=p.rig.target(std::clamp(bone,0,2));
    return index>=0 && index<static_cast<int>(p.bone.size()) ? p.bone[index].pos() : p.head;
}
void Aimbot::send_mouse(float dpitch, float dyaw, float sens) {
    if (!std::isfinite(dpitch) || !std::isfinite(dyaw) || !std::isfinite(sens) || sens <= 0) return;
    mouse_x_ += -dyaw / (.022f * sens);
    mouse_y_ += dpitch / (.022f * sens);
    const LONG mx = static_cast<LONG>(std::clamp(mouse_x_, -32767.f, 32767.f));
    const LONG my = static_cast<LONG>(std::clamp(mouse_y_, -32767.f, 32767.f));
    if (!mx && !my) return;
    INPUT input{}; input.type = INPUT_MOUSE;
    input.mi.dx = mx; input.mi.dy = my; input.mi.dwFlags = MOUSEEVENTF_MOVE;
    if (input_.send(1, &input, sizeof(input)) == 1) { mouse_x_ -= mx; mouse_y_ -= my; }
    else mouse_x_ = mouse_y_ = 0;
}
void Aimbot::update(const EntityCache& cache, const Config& cfg, Memory*) {
    const auto* local = cache.local();
    if (!local || !local->valid() || !local->eye.finite() || !local->eye_angles.finite()) { reset(); return; }
    const float sensitivity = cache.sensitivity() * cfg.aim_sens;
    const auto now=input_.now();
    const float dt=last_update_ ? std::clamp((now-last_update_)/1000.f,.001f,.05f) : 1.f/60.f;
    last_update_=now;
    Vec3 view=local->eye_angles;
    cache.current_view_angles(view);
    const bool held = cfg.aim && (input_.key(cfg.aim_key) & 0x8000) &&
        (!cfg.aim_ads_only || (input_.key(VK_RBUTTON) & 0x8000));
    const PlayerEnt* best = nullptr;
    float score = (std::numeric_limits<float>::max)();
    if (held) for (const auto& p : cache.players()) {
        if (p.is_local || !p.valid() || p.team == local->team) continue;
        const auto target = get_bone_pos(p, cfg.aim_bone);
        if (!target.finite()) continue;
        const auto angle = calc_angle(local->eye, target);
        const float fov = std::hypot(normalize(angle.x - view.x), normalize(angle.y - view.y));
        if (fov > cfg.aim_fov) continue;
        const float candidate = cfg.aim_target == 0 ? fov : (target - local->eye).len();
        if (candidate < score) { score = candidate; best = &p; }
    }
    bool applied = false;
    if (best) {
        if (target_ != best->pawn) { target_ = best->pawn; target_since_ = now; mouse_x_ = mouse_y_ = 0; }
        if (now - target_since_ >= static_cast<ULONGLONG>(cfg.aim_delay_ms)) {
            auto angle = calc_angle(local->eye, get_bone_pos(*best, cfg.aim_bone));
            if (cfg.rcs && local->punch_angle.finite()) angle = angle - local->punch_angle * (2.f * cfg.rcs_intensity);
            const float smoothing = (std::max)(1.f, cfg.aim_smooth);
            const float blend=smoothing<=1.f ? 1.f : 1.f-std::pow(1.f-1.f/smoothing,dt*60.f);
            send_mouse(normalize(angle.x - view.x)*blend, normalize(angle.y - view.y)*blend, sensitivity);
            applied = true;
        }
    } else { target_ = 0; target_since_ = 0; }
    if (cfg.rcs && local->shots_fired > 1 && local->punch_angle.finite()) {
        const auto punch = local->punch_angle * (2.f * cfg.rcs_intensity);
        const auto delta = punch - prev_punch_;
        if (!applied) send_mouse(-delta.x, -delta.y, sensitivity);
        prev_punch_ = punch;
    } else prev_punch_ = {};
}
