#include "entities.hpp"
#include <algorithm>
#include <cstring>

bool EntityCache::init(Memory* mem) { mem_ = mem; return mem != nullptr; }
bool EntityCache::resolve() {
    if (!mem_ || !mem_->is_valid()) return false;
    client_ = mem_->get_module_base("client.dll");
    const auto engine = mem_->get_module_base("engine2.dll");
    if (!client_ || !engine) { status_ = "Aguardando modulos do CS2"; return false; }
    const auto build = mem_->read<uint32_t>(engine + game_offsets::dwBuildNumber);
    if (build != offsets::BUILD_NUMBER) {
        status_ = "Build incompativel: " + std::to_string(build) + "; esperado " + std::to_string(offsets::BUILD_NUMBER);
        return false;
    }
    const auto pe = mem_->read<uint32_t>(client_ + 0x3C);
    if (!pe || mem_->read<uint32_t>(client_ + pe + 8) != offsets::CLIENT_TIMESTAMP ||
        mem_->read<uint32_t>(client_ + pe + 0x50) != offsets::CLIENT_IMAGE_SIZE) {
        status_ = "client.dll incompativel com os offsets extraidos";
        return false;
    }
    ent_system = client_ + game_offsets::dwEntityList;
    local_ctrl = client_ + game_offsets::dwLocalPlayerController;
    vm_addr = client_ + game_offsets::dwViewMatrix;
    c4_list = client_ + game_offsets::dwPlantedC4;
    globals_addr = client_ + game_offsets::dwGlobalVars;
    view_angles_addr = client_ + game_offsets::dwViewAngles;
    return true;
}
uintptr_t EntityCache::entity_at(uint32_t index) const {
    if (!system_ || index > 0x7FFE) return 0;
    const auto chunk = mem_->read<uintptr_t>(system_ + offsets::ENT_LIST_OFFSET + 8ULL * (index >> 9));
    return chunk ? mem_->read<uintptr_t>(chunk + offsets::ENT_IDENT_SIZE * (index & 0x1FF)) : 0;
}
uintptr_t EntityCache::entity_handle(uint32_t handle) const {
    if (!handle || handle == UINT32_MAX) return 0;
    return entity_at(handle & 0x7FFF);
}
void EntityCache::update() {
    ready_ = false;
    sampled_at_=GetTickCount64();
    if (!mem_ || !mem_->is_valid()) { status_ = "CS2 desconectado"; return; }
    if (!ent_system && !resolve()) return;
    system_ = mem_->read<uintptr_t>(ent_system);
    update_vm(); update_entities(); update_bomb();
    if (GetTickCount64() - last_items_ >= 250) { update_items(); last_items_ = GetTickCount64(); }
    if (!system_) status_ = "Lista de entidades indisponivel";
    else if (!local()) status_ = "Aguardando jogador local / partida";
    else { ready_ = true; status_ = "CS2 build " + std::to_string(offsets::BUILD_NUMBER) + " | Jogadores: " + std::to_string(players_.size()); }
    const auto sens = mem_->read<uintptr_t>(client_ + game_offsets::dwSensitivity);
    const float value = mem_->read<float>(sens + game_offsets::dwSensitivity_sensitivity);
    if (std::isfinite(value) && value >= .01f && value <= 20.f) sensitivity_ = value;
}
void EntityCache::update_vm() {
    Matrix4x4 value{};
    if (vm_addr && mem_->read_into(vm_addr, value)) vm_ = value;
    else vm_ = {};
}
void EntityCache::update_entities() {
    players_.clear(); local_index_ = static_cast<size_t>(-1);
    if (!system_) return;
    const auto current = mem_->read<uintptr_t>(local_ctrl);
    for (int i = 1; i <= 64; ++i) {
        const auto ctrl = entity_at(i);
        if (!ctrl) continue;
        const int team = mem_->read<uint8_t>(ctrl + offsets::m_iTeamNum);
        if (team != 2 && team != 3) continue;
        PlayerEnt p{};
        p.ctrl = ctrl; p.team = team; p.controller_index = i; p.is_local = ctrl == current;
        p.alive = mem_->read<bool>(ctrl + offsets::m_bPawnIsAlive);
        p.helmet = mem_->read<bool>(ctrl + offsets::m_bPawnHasHelmet);
        p.pawn = entity_handle(mem_->read<uint32_t>(ctrl + offsets::m_hPlayerPawn));
        if (!p.alive) {
            const auto observer = entity_handle(mem_->read<uint32_t>(ctrl + offsets::m_hObserverPawn));
            if (observer) p.pawn = observer;
        }
        if (p.pawn) read_player(p, ctrl, p.pawn, system_);
        const auto nptr = mem_->read<uintptr_t>(ctrl + offsets::m_sSanitizedPlayerName);
        const auto bytes = nptr ? mem_->read_bytes(nptr, sizeof(p.name) - 1) : std::vector<uint8_t>{};
        if (!bytes.empty()) std::memcpy(p.name, bytes.data(), bytes.size());
        players_.push_back(std::move(p));
    }
    for (size_t i=0;i<players_.size();++i) if (players_[i].is_local) { local_index_=i; break; }
}
void EntityCache::read_player(PlayerEnt& p, uintptr_t, uintptr_t pawn, uintptr_t) {
    p.health = mem_->read<int>(pawn + offsets::m_iHealth);
    p.armor = mem_->read<int>(pawn + offsets::m_ArmorValue);
    p.scoped = mem_->read<bool>(pawn + offsets::m_bIsScoped);
    p.defusing = mem_->read<bool>(pawn + offsets::m_bIsDefusing);
    p.flash = mem_->read<float>(pawn + offsets::m_flFlashOverlayAlpha);
    const auto observer = mem_->read<uintptr_t>(pawn + offsets::m_pObserverServices);
    if (observer) p.obs_target = entity_handle(mem_->read<uint32_t>(observer + offsets::m_hObserverTarget));
    const auto punch = mem_->read<uintptr_t>(pawn + offsets::m_pAimPunchServices);
    if (punch) p.punch_angle = mem_->read<Vec3>(punch + offsets::m_predictableBaseAngle) + mem_->read<Vec3>(punch + offsets::m_unpredictableBaseAngle);
    p.eye_angles = mem_->read<Vec3>(p.is_local ? view_angles_addr : pawn + offsets::m_angEyeAngles);
    p.shots_fired = mem_->read<int>(pawn + offsets::m_iShotsFired);
    if (p.is_local) {
        const int index = mem_->read<int>(pawn + offsets::m_iIDEntIndex);
        if (index > 0 && index < 0x7FFF) p.crosshair_target = entity_at(static_cast<uint32_t>(index));
    }
    p.spotted_by = mem_->read<uint64_t>(pawn + offsets::m_entitySpottedState + offsets::m_bSpottedByMask);
    const auto scene = mem_->read<uintptr_t>(pawn + offsets::m_pGameSceneNode);
    if (scene) { p.origin = mem_->read<Vec3>(scene + offsets::m_vecAbsOrigin); p.dormant = mem_->read<bool>(scene + offsets::m_bDormant); }
    read_bones(p, pawn);
    p.head = p.bones_valid ? p.bone[p.rig.target(0)].pos() : p.origin + Vec3{0, 0, 64};
    const auto view = mem_->read<Vec3>(pawn + offsets::m_vecViewOffset);
    p.eye = view.finite() && view.z > 0.f && view.z < 100.f ? p.origin + view : p.head;
    read_weapon(p, pawn, system_);
}
void EntityCache::read_bones(PlayerEnt& p, uintptr_t pawn) {
    const auto scene = mem_->read<uintptr_t>(pawn + offsets::m_pGameSceneNode);
    const auto array = scene ? mem_->read<uintptr_t>(scene + offsets::m_modelState + offsets::m_pBoneArray) : 0;
    if (!array) return;
    const auto binding = mem_->read<uintptr_t>(scene + offsets::m_modelState + offsets::m_hModel);
    const auto model = binding ? mem_->read<uintptr_t>(binding) : 0;
    if (model) {
        auto found=model_rigs_.find(model);
        if (found==model_rigs_.end()) {
            const int count=mem_->read<int>(model + offsets::MODEL_BONE_NAME_COUNT);
            const auto names=mem_->read<uintptr_t>(model + offsets::MODEL_BONE_NAME_DATA);
            if (count>0 && count<=512 && names) {
                std::vector<std::string> values; values.reserve(count);
                for (int i=0;i<count;++i) {
                    const auto ptr=mem_->read<uintptr_t>(names + i*8ULL);
                    const auto bytes=ptr ? mem_->read_bytes(ptr,80) : std::vector<uint8_t>{};
                    const auto end=std::find(bytes.begin(),bytes.end(),uint8_t{0});
                    values.emplace_back(bytes.begin(),end);
                }
                found=model_rigs_.emplace(model,bones::from_names(values)).first;
            }
        }
        if (found!=model_rigs_.end()) p.rig=found->second;
    }
    const int count=p.rig.read_count();
    const int head_index=p.rig.target(0);
    if (count<=0 || count>static_cast<int>(p.bone.size()) || head_index<0) return;
    const auto raw=mem_->read_bytes(array,count*sizeof(BoneMat));
    if (raw.size()!=count*sizeof(BoneMat)) return;
    std::memcpy(p.bone.data(),raw.data(),raw.size());
    const auto head = p.bone[head_index].pos();
    p.bones_valid = head.finite() && (head - p.origin).len() < 150.f && (head - p.origin).len() > 1.f;
}
void EntityCache::read_weapon(PlayerEnt& p, uintptr_t pawn, uintptr_t) {
    const auto services = mem_->read<uintptr_t>(pawn + offsets::m_pWeaponServices);
    if (!services) return;
    const auto active = entity_handle(mem_->read<uint32_t>(services + offsets::m_hActiveWeapon));
    if (active) {
        p.weapon_id = mem_->read<uint16_t>(active + offsets::m_AttributeManager + offsets::m_Item + offsets::m_iItemDefinitionIndex);
        p.clip = mem_->read<int>(active + offsets::m_iClip1);
        p.reserve = mem_->read<int>(active + offsets::m_pReserveAmmo);
    }
    const auto count = mem_->read<int>(services + offsets::m_hMyWeapons);
    const auto data = mem_->read<uintptr_t>(services + offsets::m_hMyWeapons + 8);
    if (!data || count < 0 || count > 64) return;
    for (int i = 0; i < count; ++i) {
        const auto weapon = entity_handle(mem_->read<uint32_t>(data + i * 4ULL));
        if (!weapon) continue;
        const auto id = mem_->read<uint16_t>(weapon + offsets::m_AttributeManager + offsets::m_Item + offsets::m_iItemDefinitionIndex);
        if (weapons::is_utility(id)) p.util_ids.push_back(id);
    }
}
void EntityCache::update_items() {
    items_.clear();
    if (!system_) return;
    const auto highest = mem_->read<int>(system_ + game_offsets::dwGameEntitySystem_highestEntityIndex);
    if (highest < 65 || highest > 0x7FFE) return;
    for (int i = 65; i <= highest; ++i) {
        const auto ent = entity_at(i);
        if (!ent) continue;
        const auto identity = mem_->read<uintptr_t>(ent + offsets::m_pEntity);
        const auto name_ptr = identity ? mem_->read<uintptr_t>(identity + offsets::m_designerName) : 0;
        const auto name = name_ptr ? mem_->read_bytes(name_ptr, 64) : std::vector<uint8_t>{};
        if (name.size() < 7 || std::memcmp(name.data(), "weapon_", 7) != 0) continue;
        const auto owner = mem_->read<uint32_t>(ent + offsets::m_hOwnerEntity);
        if (owner != UINT32_MAX && entity_handle(owner)) continue;
        const auto scene = mem_->read<uintptr_t>(ent + offsets::m_pGameSceneNode);
        if (!scene) continue;
        WorldItem item;
        item.origin = mem_->read<Vec3>(scene + offsets::m_vecAbsOrigin);
        item.weapon_id = mem_->read<uint16_t>(ent + offsets::m_AttributeManager + offsets::m_Item + offsets::m_iItemDefinitionIndex);
        if (item.weapon_id && item.origin.finite()) items_.push_back(item);
    }
}
void EntityCache::update_bomb() {
    bomb_ = {};
    if (!c4_list) return;
    const auto c4 = mem_->read<uintptr_t>(c4_list);
    if (!c4) return;
    bomb_.ticking = mem_->read<bool>(c4 + offsets::m_bBombTicking);
    bomb_.defused = mem_->read<bool>(c4 + offsets::m_bBombDefused);
    bomb_.planted = bomb_.ticking && !bomb_.defused;
    bomb_.blow_time = mem_->read<float>(c4 + offsets::m_flC4Blow);
    bomb_.timer_length = mem_->read<float>(c4 + offsets::m_flTimerLength);
    bomb_.defuse_end = mem_->read<float>(c4 + offsets::m_flDefuseCountDown);
    bomb_.site = mem_->read<int>(c4 + offsets::m_nBombSite);
    const auto globals = mem_->read<uintptr_t>(globals_addr);
    const auto now = mem_->read<float>(globals + offsets::GLOBAL_CURTIME);
    const float remaining = bomb_.blow_time - now;
    bomb_.clock_valid = globals && std::isfinite(now) && now > 0 && std::isfinite(remaining) && bomb_.timer_length > 0 && remaining >= -1 && remaining <= bomb_.timer_length + 1;
    bomb_.planted = bomb_.planted && bomb_.clock_valid && remaining > 0;
    if (bomb_.clock_valid) {
        bomb_.remaining = (std::max)(0.f, remaining);
        if (mem_->read<bool>(c4 + offsets::m_bBeingDefused)) bomb_.defuse_remaining = (std::max)(0.f, bomb_.defuse_end - now);
    }
    const auto scene = mem_->read<uintptr_t>(c4 + offsets::m_pGameSceneNode);
    if (scene) bomb_.pos = mem_->read<Vec3>(scene + offsets::m_vecAbsOrigin);
}
