#include "entities.hpp"
#include "aimbot.hpp"
#include "misc.hpp"
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <filesystem>

static void check(bool value, const char* message) { if (!value) throw std::runtime_error(message); }
template<class T, class Buffer> static void put(Buffer& buffer, size_t offset, T value) {
    check(offset + sizeof(T) <= buffer.size(), "fixture overflow");
    std::memcpy(buffer.data() + offset, &value, sizeof(value));
}
static std::vector<INPUT> sent;
static ULONGLONG clock_ms = 1000;
static bool held = true;
static UINT WINAPI record_input(UINT count, LPINPUT input, int) { sent.insert(sent.end(), input, input+count); return count; }
static SHORT WINAPI key_state(int) { return held ? static_cast<SHORT>(0x8000) : 0; }
static ULONGLONG WINAPI test_clock() { return clock_ms; }
int main() {
    Memory memory;
    try {
        char path[MAX_PATH]{}; GetModuleFileNameA(nullptr, path, MAX_PATH);
        check(memory.attach(std::filesystem::path(path).filename().string()), "self read handle");
        std::vector<uint8_t> system(0x3000), chunk0(0x70*512), chunk1(0x70*512);
        std::vector<uint8_t> local_ctrl(0x1000), enemy_ctrl(0x1000), observer_ctrl(0x1000);
        std::vector<uint8_t> local_pawn(0x4000), enemy_pawn(0x4000), observer_pawn(0x4000);
        std::vector<uint8_t> local_scene(0x300), enemy_scene(0x300), observer_services(0x100), weapon_services(0x100), weapon(0x2000);
        std::array<BoneMat,32> local_bones{}, enemy_bones{};
        const auto addr=[](const auto& buffer) { return reinterpret_cast<uintptr_t>(buffer.data()); };
        put(system,0x10,addr(chunk0)); put(system,0x18,addr(chunk1));
        put(chunk0,0x70,addr(local_ctrl)); put(chunk0,0xE0,addr(enemy_ctrl)); put(chunk0,0x150,addr(observer_ctrl));
        put(chunk0,0x70*70,addr(local_pawn)); put(chunk1,0x70*(600-512),addr(enemy_pawn)); put(chunk0,0x70*71,addr(observer_pawn));
        put(local_ctrl,offsets::m_iTeamNum,uint8_t{2}); put(enemy_ctrl,offsets::m_iTeamNum,uint8_t{3}); put(observer_ctrl,offsets::m_iTeamNum,uint8_t{2});
        put(local_ctrl,offsets::m_bPawnIsAlive,true); put(enemy_ctrl,offsets::m_bPawnIsAlive,true);
        put(local_ctrl,offsets::m_hPlayerPawn,uint32_t{0x460000|70}); put(enemy_ctrl,offsets::m_hPlayerPawn,uint32_t{0x460000|600});
        put(observer_ctrl,offsets::m_hObserverPawn,uint32_t{71});
        put(local_pawn,offsets::m_iHealth,100); put(enemy_pawn,offsets::m_iHealth,87);
        put(local_pawn,offsets::m_pGameSceneNode,addr(local_scene)); put(enemy_pawn,offsets::m_pGameSceneNode,addr(enemy_scene));
        put(local_scene,offsets::m_vecAbsOrigin,Vec3{10,20,30}); put(enemy_scene,offsets::m_vecAbsOrigin,Vec3{100,200,300});
        local_bones[bones::HEAD].position={10,20,94}; enemy_bones[bones::HEAD].position={100,200,364};
        put(local_scene,offsets::m_modelState+offsets::m_pBoneArray,addr(local_bones));
        put(enemy_scene,offsets::m_modelState+offsets::m_pBoneArray,addr(enemy_bones));
        put(observer_pawn,offsets::m_pObserverServices,addr(observer_services)); put(observer_services,offsets::m_hObserverTarget,uint32_t{70});
        put(local_pawn,offsets::m_pWeaponServices,addr(weapon_services)); put(weapon_services,offsets::m_hActiveWeapon,uint32_t{72});
        put(chunk0,0x70*72,addr(weapon)); put(weapon,offsets::m_AttributeManager+offsets::m_Item+offsets::m_iItemDefinitionIndex,uint16_t{7});
        put(weapon,offsets::m_iClip1,30); put(weapon,offsets::m_pReserveAmmo,90);
        uintptr_t system_ptr=addr(system), local_ptr=addr(local_ctrl);
        EntityCache cache; cache.init(&memory);
        cache.ent_system=reinterpret_cast<uintptr_t>(&system_ptr); cache.local_ctrl=reinterpret_cast<uintptr_t>(&local_ptr);
        cache.update();
        check(cache.ready() && cache.players().size()==3,"controller iteration");
        check(cache.local() && cache.local()->pawn==addr(local_pawn),"handle serial mask");
        check(cache.players()[1].pawn==addr(enemy_pawn) && cache.players()[1].health==87,"cross-chunk handle");
        check(cache.players()[1].bones_valid && cache.players()[1].head.z==364,"32-byte transform positions");
        check(cache.players()[2].obs_target==addr(local_pawn),"dead observer target resolution");
        check(cache.local()->weapon_id==7 && cache.local()->clip==30 && cache.local()->reserve==90,"active weapon service and nested item");
        check(cache.entity_handle(UINT32_MAX)==0 && cache.entity_handle(0)==0,"invalid handles");
        // Exercise input behavior with a recording sink: nothing reaches the real mouse.
        const InputApi input{record_input,key_state,test_clock};
        enemy_bones[bones::HEAD].position={110,30,94};
        put(enemy_scene,offsets::m_vecAbsOrigin,Vec3{110,30,30}); cache.update();
        Config cfg; cfg.aim=true; cfg.aim_ads_only=false; cfg.aim_fov=15; cfg.aim_smooth=1; cfg.aim_delay_ms=100;
        Aimbot aim(input); aim.update(cache,cfg,&memory);
        check(sent.empty(),"aim waits without sleeping");
        clock_ms=1099; aim.update(cache,cfg,&memory); check(sent.empty(),"aim acquisition delay respected");
        clock_ms=1100; aim.update(cache,cfg,&memory);
        check(sent.size()==1 && sent.back().mi.dx<0 && sent.back().mi.dwFlags==MOUSEEVENTF_MOVE,"Source yaw maps to negative mouse X");
        sent.clear(); aim.reset(); cfg.aim_target=1; cfg.aim_fov=1; cfg.aim_delay_ms=0;
        aim.update(cache,cfg,&memory); check(sent.empty(),"distance targeting still enforces FOV");
        cfg.aim=false; cfg.rcs=true;
        std::vector<uint8_t> punch(0x100);
        put(local_pawn,offsets::m_pAimPunchServices,addr(punch));
        put(punch,offsets::m_predictableBaseAngle,Vec3{1.5f,1.f,0});
        put(local_pawn,offsets::m_iShotsFired,3); cache.update();
        aim.update(cache,cfg,&memory);
        check(sent.size()==1 && sent.back().mi.dy<0 && sent.back().mi.dx>0,"standalone recoil compensation works with aimbot off");
        sent.clear(); aim.update(cache,cfg,&memory);
        check(sent.empty(),"unchanged recoil is not repeatedly accumulated");
        Matrix4x4 vm{}; vm.m[0][0]=.001f; vm.m[0][3]=-.11f; vm.m[1][1]=.001f; vm.m[1][3]=-.03f; vm.m[3][3]=1;
        cache.vm_addr=reinterpret_cast<uintptr_t>(&vm); cache.update();
        Misc misc(input); cfg.rcs=false; cfg.triggerbot=true; cfg.tb_delay_ms=75; cfg.tb_release_ms=20;
        clock_ms=1900; misc.update(cache,cfg,&memory,800,600); check(sent.empty(),"screen overlap alone cannot trigger a shot");
        put(local_pawn,offsets::m_iIDEntIndex,600); cache.update();
        clock_ms=2000; misc.update(cache,cfg,&memory,800,600); check(sent.empty(),"trigger acquisition delay");
        clock_ms=2074; misc.update(cache,cfg,&memory,800,600); check(sent.empty(),"trigger does not fire early");
        clock_ms=2075; misc.update(cache,cfg,&memory,800,600);
        check(sent.size()==1 && sent.back().mi.dwFlags==MOUSEEVENTF_LEFTDOWN,"trigger uses game crosshair entity and presses");
        clock_ms=2094; misc.update(cache,cfg,&memory,800,600); check(sent.size()==1,"trigger release is nonblocking");
        clock_ms=2095; misc.update(cache,cfg,&memory,800,600);
        check(sent.size()==2 && sent.back().mi.dwFlags==MOUSEEVENTF_LEFTUP,"trigger releases on deadline");
        clock_ms=2170; misc.update(cache,cfg,&memory,800,600); misc.reset();
        check(sent.back().mi.dwFlags==MOUSEEVENTF_LEFTUP,"pause cannot leave injected button held");
        check(memory.attach_write(std::filesystem::path(path).filename().string()),"self write handle");
        cfg.triggerbot=false; cfg.no_flash=true;
        put(local_pawn,offsets::m_flFlashMaxAlpha,255.f);
        misc.update(cache,cfg,&memory,800,600);
        check(memory.read<float>(addr(local_pawn)+offsets::m_flFlashMaxAlpha)==0.f,"no flash changes the intended alpha field");
        cfg.no_flash=false; misc.update(cache,cfg,&memory,800,600);
        check(memory.read<float>(addr(local_pawn)+offsets::m_flFlashMaxAlpha)==255.f,"disabling no flash restores original alpha");
        std::vector<uint8_t> bomb(0x2000), globals(0x100);
        uintptr_t bomb_ptr=addr(bomb), globals_ptr=addr(globals);
        cache.c4_list=reinterpret_cast<uintptr_t>(&bomb_ptr); cache.globals_addr=reinterpret_cast<uintptr_t>(&globals_ptr);
        put(bomb,offsets::m_bBombTicking,true); put(bomb,offsets::m_flC4Blow,130.f); put(bomb,offsets::m_flTimerLength,40.f);
        put(globals,0x30,100.f); cache.update();
        check(cache.bomb().planted && cache.bomb().clock_valid && cache.bomb().remaining==30.f,"bomb uses direct pointer and game time");
        put(globals,0x30,110.f); put(bomb,offsets::m_bBeingDefused,true); put(bomb,offsets::m_flDefuseCountDown,118.f); cache.update();
        check(cache.bomb().remaining==20.f && cache.bomb().defuse_remaining==8.f,"bomb and defuse countdowns advance together");
        put(globals,0x30,131.f); cache.update(); check(!cache.bomb().planted,"expired bomb is not kept on radar");
        bomb_ptr=0; cache.update(); check(!cache.bomb().planted && !cache.bomb().clock_valid,"bomb removal clears stale timer");
        system_ptr=0; cache.update(); check(!cache.ready() && cache.players().empty() && !cache.local(),"clears stale data");
        memory.detach(); std::puts("PASS: handles, chunks, bones, weapons, observers, aim direction/FOV/delay, standalone RCS, trigger deadlines/release, no-flash restoration, stale-data reset.");
    } catch (const std::exception& error) { memory.detach(); std::fprintf(stderr,"FAIL: %s\n",error.what()); return 1; }
}
