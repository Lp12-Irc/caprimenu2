// language: C++20, file: misc.hpp, target: Windows 11 x64
#pragma once
#include "entities.hpp"
#include "config.hpp"
#include "memory.hpp"
#include "input.hpp"

class Misc {
public:
    explicit Misc(InputApi input = {}) : input_(input) {}
    void update(const EntityCache& cache, const Config& cfg, Memory* mem, int sw, int sh);
    void reset();
    // Triggerbot state machine (delay needs wall clock)
    void tick_triggerbot(const EntityCache& cache, const Config& cfg, int sw, int sh);

private:
    uintptr_t enemy_under_crosshair(const EntityCache& cache, int sw, int sh) const;
    void apply_no_flash(const EntityCache& cache, const Config& cfg, Memory* mem);

    DWORD64 tb_fire_time_  = 0;
    bool    tb_fired_      = false;
    DWORD64 tb_release_time_ = 0;
    uintptr_t tb_target_ = 0;
    Memory* flash_memory_ = nullptr;
    uintptr_t flash_pawn_ = 0;
    float original_alpha_ = 255.f;
    void restore_flash();
    void reset_trigger();
    InputApi input_;
};
