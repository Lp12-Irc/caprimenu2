#pragma once
#include <Windows.h>

// Production uses Win32. Tests supply a recording sink and deterministic clock.
struct InputApi {
    decltype(&SendInput) send = &SendInput;
    decltype(&GetAsyncKeyState) key = &GetAsyncKeyState;
    decltype(&GetTickCount64) now = &GetTickCount64;
};
