// language: C++20, file: main.cpp, target: Windows 11 x64, MSVC
// Entry: wait for cs2.exe → resolve patterns → spawn cache thread → render loop
#include "string_enc.hpp"
#include "anti_debug.hpp"
#include "memory.hpp"
#include "offsets.hpp"
#include "entities.hpp"
#include "overlay.hpp"
#include "esp.hpp"
#include "aimbot.hpp"
#include "misc.hpp"
#include "menu.hpp"
#include "brand.hpp"
#include "config.hpp"
#include "auth.hpp"
#include "login.hpp"
#include <filesystem>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#include <thread>
#include <atomic>
#include <random>
#include <mutex>
#include <condition_variable>
#include <Windows.h>

static std::atomic<bool> g_running{true};
static std::mutex g_stop_mutex;
static std::mutex g_cache_mutex;
static std::condition_variable g_stop_cv;

static void resolve_offsets(Memory& mem, EntityCache& cache) {
    auto client = ENC("client.dll").decrypt();

    // EntitySystem
    uintptr_t es_sig = mem.pattern_scan(client, patterns::ENTITY_SYSTEM);
    cache.ent_system  = es_sig ? mem.resolve_rip(es_sig, 3, 7) : 0;

    // LocalPlayerController
    uintptr_t lp_sig  = mem.pattern_scan(client, patterns::LOCAL_PLAYER_CTRL);
    cache.local_ctrl   = lp_sig ? mem.resolve_rip(lp_sig, 3, 7) : 0;

    // ViewMatrix
    uintptr_t vm_sig  = mem.pattern_scan(client, patterns::VIEW_MATRIX);
    cache.vm_addr      = vm_sig ? mem.resolve_rip(vm_sig, 3, 7) : 0;

    // PlantedC4
    uintptr_t c4_sig  = mem.pattern_scan(client, patterns::PLANTED_C4);
    cache.c4_list      = c4_sig ? mem.resolve_rip(c4_sig, 3, 7) : 0;
}

static void entity_thread_fn(EntityCache& cache,
                              const std::atomic<bool>& running) {
    std::mt19937 rng(GetTickCount());
    std::uniform_int_distribution<int> jitter(10, 17); // 60-100Hz jitter

    while (running.load()) {
        { std::lock_guard<std::mutex> lock(g_cache_mutex); cache.update(); }
        Sleep(jitter(rng)); // randomized interval — avoid 1000Hz constant pattern
        anti_debug::watchdog_tick(); // silent exit if debugger attaches mid-session
    }
}

int WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    // ── Anti-debug ──────────────────────────────────────────────────────────
    anti_debug::run();

    ImGui_ImplWin32_EnableDpiAwareness();

    // ── Config ──────────────────────────────────────────────────────────────
    wchar_t exe_path[MAX_PATH]{};
    if (GetModuleFileNameW(nullptr, exe_path, MAX_PATH))
        std::filesystem::current_path(std::filesystem::path(exe_path).parent_path());
    Config cfg;
    cfg.load("configs/default.hbc");

    // ── Auth ─────────────────────────────────────────────────────────────────
    Auth    auth;
    AuthInfo auth_info;
    if (!show_login(cfg, auth, auth_info)) return 0;
    cfg.menu_open = true;

    // ── Wait for CS2 ─────────────────────────────────────────────────────────
    Memory mem;
    while (!mem.attach(ENC("cs2.exe").decrypt())) Sleep(1000);

    // ── Resolve offsets ───────────────────────────────────────────────────────
    EntityCache cache;
    cache.init(&mem);
    resolve_offsets(mem, cache);

    // Optional write handle (silent aim / no-flash)
    if (cfg.silent_aim || cfg.no_flash)
        mem.attach_write(ENC("cs2.exe").decrypt());

    // ── Overlay ───────────────────────────────────────────────────────────────
    Overlay overlay;
    if (!overlay.create(ENC("Counter-Strike 2").decrypt())) {
        MessageBoxW(nullptr, L"Nao foi possivel iniciar a janela Direct3D. Abra o CS2 em janela ou sem bordas.", L"Capri", MB_OK | MB_ICONERROR);
        return 1;
    }

    // ── ImGui ─────────────────────────────────────────────────────────────────
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; // don't write imgui.ini

    Brand::init(overlay.device());
    Menu::apply_theme();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    ImGui_ImplWin32_Init(overlay.hwnd());
    ImGui_ImplDX11_Init(overlay.device(), overlay.context());
    if (!io.Fonts->AddFontFromFileTTF("C:/Windows/Fonts/segoeui.ttf", 18.f))
        io.Fonts->AddFontDefault();
    overlay.set_interactive(cfg.menu_open);

    // ── Subsystems ────────────────────────────────────────────────────────────
    Esp    esp;
    Aimbot aimbot;
    Misc   misc;
    Menu   menu;

    // ── Entity cache thread ───────────────────────────────────────────────────
    std::thread ent_thread(entity_thread_fn, std::ref(cache), std::ref(g_running));

    // ── Periodic revalidation thread (every 5 minutes) ────────────────────────
    const std::string session_key = cfg.saved_key;
    std::thread auth_thread([&]() {
        std::unique_lock<std::mutex> lock(g_stop_mutex);
        while (!g_stop_cv.wait_for(lock, std::chrono::minutes(5), [] { return !g_running.load(); })) {
            lock.unlock();
            bool valid = auth.revalidate(session_key, auth_info.hwid);
            lock.lock();
            if (!valid) { g_running.store(false); break; }
        }
    });

    // ── Render loop ───────────────────────────────────────────────────────────
    while (g_running.load()) {
        if (!overlay.begin_frame()) break;

        // Toggle menu
        static bool menu_key_last = false;
        bool menu_key_now = (GetAsyncKeyState(cfg.menu_key) & 0x8000) != 0;
        if (menu_key_now && !menu_key_last && overlay.visible()) cfg.menu_open = !cfg.menu_open;
        overlay.set_interactive(cfg.menu_open);
        menu_key_last = menu_key_now;

        // Check if CS2 still running
        if (!mem.is_valid()) break;
        if (!overlay.visible()) { Sleep(30); continue; }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // ESP on background draw list
        int sw = overlay.width(), sh = overlay.height();
        {
        std::lock_guard<std::mutex> lock(g_cache_mutex);
        cfg.item_esp = cfg.spectator_list = cfg.bomb_timer = cfg.esp_utilities = false;
        esp.render(cache, cfg, ImGui::GetBackgroundDrawList(), sw, sh);

        // Aimbot
        if (!cfg.menu_open) aimbot.update(cache, cfg, &mem);

        // Misc (no-flash, triggerbot)
        if (!cfg.menu_open) misc.update(cache, cfg, &mem);
        }

        // Menu
        if (cfg.menu_open) {
            bool running = g_running.load();
            menu.render(cfg, auth_info, running);
            if (!running) g_running.store(false);
        }

        overlay.set_interactive(cfg.menu_open);
        ImGui::Render();
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        overlay.end_frame();
    }

    { std::lock_guard<std::mutex> lock(g_stop_mutex); g_running.store(false); }
    g_stop_cv.notify_all();
    ent_thread.join();
    auth_thread.join();

    Brand::shutdown();
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    overlay.destroy();
    mem.detach();
    return 0;
}
